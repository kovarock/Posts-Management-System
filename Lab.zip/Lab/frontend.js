document.addEventListener('DOMContentLoaded', () => {
  const postList = document.getElementById('postList');
  const postForm = document.getElementById('postForm');

  // Отримати пости та відобразити їх
  fetch('/')
    .then(response => response.json())
    .then(posts => {
      posts.forEach(post => {
        const listItem = document.createElement('li');
        listItem.textContent = `${post.title} - ${post.author}`;
        postList.appendChild(listItem);
      });
    })
    .catch(error => console.error('Помилка при отриманні постів:', error));

  // Додати обробник подій для створення нового посту
  postForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const title = document.getElementById('title').value;
    const description = document.getElementById('description').value;
    const author = document.getElementById('author').value;

    fetch('/create', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ title, description, author }),
    })
      .then(response => response.json())
      .then(newPost => {
        const listItem = document.createElement('li');
        listItem.textContent = `${newPost.title} - ${newPost.author}`;
        postList.appendChild(listItem);
        postForm.reset();
      })
      .catch(error => console.error('Помилка при створенні посту:', error));
  });
});
