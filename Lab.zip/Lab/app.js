const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const Post = require('./models/postModel'); // Шлях до моделі постів

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

mongoose.connect('mongodb://localhost:27017/Bodenko', { useNewUrlParser: true, useUnifiedTopology: true });

// Отримання всіх постів
app.get('/', async (req, res) => {
  try {
    const posts = await Post.find();
    res.render('index', { posts });
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// Створення нового поста
app.post('/create', async (req, res) => {
  const { title, description, author } = req.body;
  try {
    const newPost = new Post({ title, description, author });
    await newPost.save();
    res.redirect('/');
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// Редагування поста
app.post('/edit/:id', async (req, res) => {
  const { title, description, author } = req.body;
  const postId = req.params.id;
  try {
    await Post.findByIdAndUpdate(postId, { title, description, author });
    res.redirect('/');
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// Видалення поста
app.get('/delete/:id', async (req, res) => {
  const postId = req.params.id;
  try {
    await Post.findByIdAndRemove(postId);
    res.redirect('/');
  } catch (err) {
    res.status(500).send(err.message);
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
